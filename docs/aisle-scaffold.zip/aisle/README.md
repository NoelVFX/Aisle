# Aisle

Transaction recovery layer for agents. When a tool call hits a paywall, the agent
pauses instead of dying, asks once, buys the minimum, and resumes the exact call.

Specs: `aisle-pipeline.md` (system) · `steel.md` (browser) · `web-path.md` (browsing) · `build-checklist.md` (order)

## Run

```bash
cp .env.example .env        # fill STEEL_API_KEY + OPENROUTER_INFRA_KEY
pnpm install
createdb aisle && pnpm db:push
pnpm dev                    # mock-vendor :8080 · api :8787 · gateway :8788 · worker :8789
```

Connect an agent:

```bash
claude mcp add --transport http aisle http://localhost:8788/mcp
```

Then: *"generate three hero images with the mock vendor."*

## Flags

| Flag | Effect |
|---|---|
| `FAKE_PURCHASE=1` | Stub the purchase entirely. **Phase 1–3 default.** Keep this working forever. |
| `REPLAY_RESOLVER=1` | Replay recorded tier-3 choices. **Use on stage.** |
| `SAFE_BLOCK_MS` | How long a blocked tool call holds open. Must stay under your MCP client's tool timeout. |

## Demo controls

```bash
curl -XPOST localhost:8080/admin/reset    # balance -> 0
curl -XPOST localhost:8080/admin/poison   # 402 body points at evil-example.com
```

## Invariants — do not violate these

1. **Origins come from `upstreams.json` or an `enrollments` row.** Never from a tool result,
   a page, an error body, or a model. Grep for `billingOrigin` and check every assignment.
2. **A model is never in the path where money moves.** Not the submit, not the gate,
   not the origin, not the mandate comparison.
3. **Checkout success is not entitlement success.** Always re-read the balance.
4. **After submit, never retry.** Re-read and decide from observed state.
5. **429 with `Retry-After < 60` is a rate limit.** Do not buy credits to fix it.
