-- Aisle schema. Run: psql $DATABASE_URL -f db/schema.sql

CREATE TABLE IF NOT EXISTS tasks (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL,
  agent_id        TEXT,
  surface         TEXT NOT NULL CHECK (surface IN ('cli','web')),
  status          TEXT NOT NULL DEFAULT 'running',
  origin_provider TEXT,
  origin_url      TEXT,
  created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS tool_calls (
  id         TEXT PRIMARY KEY,
  task_id    TEXT REFERENCES tasks(id),
  tool_name  TEXT NOT NULL,
  arguments  JSONB NOT NULL,
  args_hash  TEXT NOT NULL,
  status     TEXT NOT NULL,
  error      JSONB,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS recovery_jobs (
  id           TEXT PRIMARY KEY,
  task_id      TEXT REFERENCES tasks(id),
  tool_call_id TEXT REFERENCES tool_calls(id),
  blocker_type TEXT NOT NULL,
  requirement  JSONB NOT NULL,
  checkpoint   JSONB NOT NULL,
  req_hash     TEXT NOT NULL,
  status       TEXT NOT NULL,
  lane         TEXT,
  created_at   TIMESTAMPTZ DEFAULT now(),
  -- IDEMPOTENCY, ENFORCED BY THE DATABASE.
  -- Same shortfall from two surfaces resolves to one job.
  UNIQUE (task_id, req_hash)
);

CREATE TABLE IF NOT EXISTS entitlements (
  id          TEXT PRIMARY KEY,
  user_id     TEXT NOT NULL,
  provider    TEXT NOT NULL,
  -- account_id is what keeps infra-openrouter separate from user-openrouter.
  -- Do NOT collapse these into one row. See aisle-pipeline.md 16.5.
  account_id  TEXT NOT NULL DEFAULT 'default',
  resource    TEXT NOT NULL,
  balance     NUMERIC,
  plan        TEXT,
  seats_used  INT,
  seats_total INT,
  renewal_at  TIMESTAMPTZ,
  status      TEXT NOT NULL DEFAULT 'active',
  verified_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, provider, account_id, resource)
);

CREATE TABLE IF NOT EXISTS quotes (
  id              TEXT PRIMARY KEY,
  recovery_job_id TEXT REFERENCES recovery_jobs(id),
  provider        TEXT, product_id TEXT, quantity INT, units_granted NUMERIC,
  price NUMERIC, currency TEXT, billing_type TEXT, auto_renew BOOL, reason TEXT
);

CREATE TABLE IF NOT EXISTS mandates (
  id             TEXT PRIMARY KEY,
  quote_id       TEXT REFERENCES quotes(id),
  task_id        TEXT,
  billing_origin TEXT NOT NULL,
  max_amount     NUMERIC NOT NULL,
  currency       TEXT NOT NULL,
  nonce          TEXT NOT NULL,
  signature      TEXT NOT NULL,
  status         TEXT NOT NULL CHECK (status IN ('pending','approved','consumed','rejected','expired')),
  expires_at     TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS purchases (
  id               TEXT PRIMARY KEY,
  mandate_id       TEXT REFERENCES mandates(id),
  provider         TEXT, amount NUMERIC, currency TEXT,
  transaction_id   TEXT, lane TEXT,
  steel_session_id TEXT, trace_export_id TEXT, receipt_file_ids TEXT[],
  status           TEXT NOT NULL CHECK (status IN ('submitted','unknown','verified','failed')),
  verified_at      TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS spend_state (
  scope    TEXT PRIMARY KEY,          -- 'task:{id}' | 'day:{user}:{yyyy-mm-dd}'
  amount   NUMERIC NOT NULL DEFAULT 0,
  attempts INT     NOT NULL DEFAULT 0
);

-- Steel profiles. One per (user, vendor). Never one per user.
CREATE TABLE IF NOT EXISTS vendor_profiles (
  user_id      TEXT NOT NULL,
  provider     TEXT NOT NULL,
  profile_id   TEXT NOT NULL,
  dedicated_ip TEXT,
  last_ok_at   TIMESTAMPTZ,
  PRIMARY KEY (user_id, provider)
);

-- WEB PATH ONLY. This table IS the origin lock for browser-triggered recoveries.
-- billing_origin is set at enrollment. NEVER derived from a 402 body or a page link.
CREATE TABLE IF NOT EXISTS enrollments (
  user_id          TEXT NOT NULL,
  provider         TEXT NOT NULL,
  canonical_origin TEXT NOT NULL,
  billing_origin   TEXT NOT NULL,
  profile_id       TEXT,
  enrolled_at      TIMESTAMPTZ DEFAULT now(),
  PRIMARY KEY (user_id, canonical_origin)
);

CREATE TABLE IF NOT EXISTS events (
  id      BIGSERIAL PRIMARY KEY,
  task_id TEXT NOT NULL,
  type    TEXT NOT NULL,
  payload JSONB DEFAULT '{}'::jsonb,
  at      TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS events_task_idx ON events (task_id, id);
