import type { Blocker, BlockerType } from "@aisle/types";

/**
 * ONE classifier, TWO transports (MCP tool errors + CDP wire responses).
 * Do not fork this for the web path.
 */

interface VendorRule {
  test: (body: any, status: number) => boolean;
  type: BlockerType;
  resource: string;
  required?: (body: any) => number | undefined;
}

const VENDOR_RULES: Record<string, VendorRule[]> = {
  mockvendor: [{
    test: (b) => b?.code === "insufficient_credits",
    type: "INSUFFICIENT_CREDITS",
    resource: "image_credits",
    required: (b) => b?.required_credits,
  }],
  openrouter: [{
    // OpenRouter 402 body shape — confirm against a real drained key and tighten.
    test: (b, s) => s === 402 || /credit|balance/i.test(b?.error?.message ?? ""),
    type: "INSUFFICIENT_CREDITS",
    resource: "usd_balance",
  }],
};

const GENERIC: VendorRule[] = [
  { test: (_b, s) => s === 402, type: "PAYMENT_REQUIRED", resource: "unknown" },
  { test: (b, s) => s === 429 && /quota|limit|exceed/i.test(str(b)), type: "QUOTA_EXCEEDED", resource: "unknown" },
  { test: (b, s) => s === 403 && /plan|upgrade|subscription/i.test(str(b)), type: "PLAN_REQUIRED", resource: "plan" },
  { test: (b, s) => s === 403 && /seat/i.test(str(b)), type: "SEAT_REQUIRED", resource: "seats" },
];

const str = (b: unknown) => (typeof b === "string" ? b : JSON.stringify(b ?? ""));

/**
 * THE 429 GUARD.
 * A rate limit is not a billing wall, and buying credits does not fix it.
 * This is the most embarrassing possible bug in this product — keep it first.
 */
export function isRateLimitNotWall(status: number, headers: Record<string, string>): boolean {
  if (status !== 429) return false;
  const ra = Number(headers["retry-after"] ?? headers["Retry-After"] ?? NaN);
  return Number.isFinite(ra) && ra < 60;
}

export function classify(
  status: number,
  body: unknown,
  provider: string,
  opts: { bodyAvailable?: boolean } = {},
): Blocker {
  const parsed = typeof body === "string" ? safeJson(body) : body;
  const confidence = opts.bodyAvailable === false ? "low" : "high";

  for (const rule of [...(VENDOR_RULES[provider] ?? []), ...GENERIC]) {
    if (!rule.test(parsed, status)) continue;
    return {
      type: rule.type,
      resource: rule.resource,
      required: rule.required?.(parsed),
      confidence,
      raw: parsed ?? body,
    };
  }
  return { type: "UNKNOWN", resource: "unknown", confidence, raw: parsed ?? body };
}

/** MCP tool errors arrive shaped differently than HTTP responses. Normalize here. */
export function classifyToolError(result: any, provider: string): Blocker {
  const status = result?.status ?? result?.error?.status ?? result?.code ?? 0;
  const body = result?.error ?? result;
  return classify(Number(status) || inferStatus(body), body, provider);
}

function inferStatus(body: any): number {
  const s = str(body);
  if (/insufficient_credits|payment_required/i.test(s)) return 402;
  if (/quota|rate_limit/i.test(s)) return 429;
  if (/requires_paid_plan|upgrade/i.test(s)) return 403;
  return 0;
}

function safeJson(s: string): unknown {
  try { return JSON.parse(s); } catch { return s; }
}
