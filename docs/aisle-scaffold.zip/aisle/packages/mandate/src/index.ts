import { createHmac, randomUUID, randomBytes } from "node:crypto";
import type { PurchaseMandate, Quote, StagedCheckout } from "@aisle/types";

const SECRET = () => process.env.MANDATE_SECRET ?? "dev-only-change-me";
const TTL_MS = 10 * 60_000;

/** Stable serialization. Signature must not depend on key order. */
function canonical(m: Omit<PurchaseMandate, "signature">): string {
  return JSON.stringify(m, Object.keys(m).sort());
}

export function signMandate(
  q: Quote,
  ctx: { taskId: string; recoveryJobId: string; userId: string },
): PurchaseMandate {
  const unsigned: Omit<PurchaseMandate, "signature"> = {
    mandateId: randomUUID(),
    taskId: ctx.taskId,
    recoveryJobId: ctx.recoveryJobId,
    userId: ctx.userId,
    provider: q.provider,
    billingOrigin: q.billingOrigin,
    productId: q.productId,
    quantity: q.quantity,
    unitsGranted: q.unitsGranted,
    // CAP, not price. tax and FX move the real number.
    maximumAmount: Math.ceil(q.price * 1.25 * 100) / 100,
    currency: q.currency,
    billingType: "one_time",
    autoRenew: false,
    expiresAt: new Date(Date.now() + TTL_MS).toISOString(),
    nonce: randomBytes(16).toString("hex"),
  };
  const signature = createHmac("sha256", SECRET()).update(canonical(unsigned)).digest("hex");
  return { ...unsigned, signature };
}

/** The worker is a separate process. It must not trust its own input. */
export function verifyMandate(m: PurchaseMandate): void {
  const { signature, ...rest } = m;
  const expected = createHmac("sha256", SECRET()).update(canonical(rest)).digest("hex");
  if (signature !== expected) throw new Error("MANDATE_SIGNATURE_INVALID");
  if (new Date(m.expiresAt).getTime() < Date.now()) throw new Error("MANDATE_EXPIRED");
  if (m.autoRenew !== false) throw new Error("MANDATE_AUTORENEW_SET");
  if (m.billingType !== "one_time") throw new Error("MANDATE_NOT_ONE_TIME");
}

/**
 * THE GATE THAT MAKES A WRONG CLICK SAFE.
 * Called immediately before submit. Never after.
 */
export function assertMatchesMandate(s: StagedCheckout, m: PurchaseMandate): void {
  if (s.amount > m.maximumAmount) {
    throw new MandateMismatch("AMOUNT_EXCEEDS_MANDATE", { staged: s.amount, cap: m.maximumAmount });
  }
  if (s.currency !== m.currency) {
    throw new MandateMismatch("CURRENCY_MISMATCH", { staged: s.currency, expected: m.currency });
  }
  if (s.billingPeriod !== "one_time") {
    throw new MandateMismatch("UNEXPECTED_SUBSCRIPTION", { staged: s.billingPeriod });
  }
  if (s.autoRenew !== false) {
    throw new MandateMismatch("AUTO_RENEW_ENABLED", {});
  }
}

export class MandateMismatch extends Error {
  constructor(public code: string, public detail: Record<string, unknown>) {
    super(`MANDATE_MISMATCH:${code}`);
  }
}
