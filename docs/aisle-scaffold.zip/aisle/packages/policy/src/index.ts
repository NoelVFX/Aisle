import type { GateResult, Limits, Quote, SpendState, TaskCheckpoint } from "@aisle/types";

export const LIMITS: Limits = {
  perPurchase: Number(process.env.LIMIT_PER_PURCHASE ?? 50),
  perTask: Number(process.env.LIMIT_PER_TASK ?? 100),
  perDay: Number(process.env.LIMIT_PER_DAY ?? 250),
  maxAttemptsPerTask: Number(process.env.MAX_PURCHASE_ATTEMPTS_PER_TASK ?? 3),
  maxResolverCallsPerJob: Number(process.env.MAX_RESOLVER_CALLS_PER_JOB ?? 5),
};

/**
 * Do not write === on raw origin strings and call it an origin lock.
 * Scheme, host, port, case, trailing slash all have to normalize.
 */
export function canonicalize(origin: string): string {
  const u = new URL(origin);
  const port = u.port && u.port !== defaultPort(u.protocol) ? `:${u.port}` : "";
  return `${u.protocol.toLowerCase()}//${u.hostname.toLowerCase()}${port}`;
}
const defaultPort = (p: string) => (p === "https:" ? "443" : p === "http:" ? "80" : "");

/** Aisle's own resolver provider can never be recovered. Keyed on KEY, not provider name. */
const NON_RECOVERABLE_KEY_HASHES = new Set<string>();
export function registerNonRecoverableKey(hash: string) { NON_RECOVERABLE_KEY_HASHES.add(hash); }
export function isNonRecoverable(hash: string) { return NON_RECOVERABLE_KEY_HASHES.has(hash); }

export function gate(
  quote: Quote,
  cp: TaskCheckpoint,
  spend: SpendState,
  limits: Limits = LIMITS,
): GateResult {
  // 1. ORIGIN LOCK — hard boundary, checked first, always.
  let attempted: string, authorized: string;
  try {
    attempted = canonicalize(quote.billingOrigin);
    authorized = canonicalize(cp.origin.billingOrigin);
  } catch {
    return refuse("ORIGIN_VIOLATION", { raw: quote.billingOrigin },
      "Purchase origin could not be parsed.");
  }
  if (attempted !== authorized) {
    return refuse("ORIGIN_VIOLATION", { attempted, authorized },
      `Purchase blocked. ${attempted} is not authorized by this task. Authorized origin is ${authorized}.`);
  }

  // 2. per purchase
  if (quote.price > limits.perPurchase) {
    return refuse("PER_PURCHASE_CEILING",
      { requested: quote.price, ceiling: limits.perPurchase },
      `Purchase blocked. $${quote.price} exceeds the $${limits.perPurchase} per-purchase ceiling.`);
  }

  // 3. per task — ALWAYS report cumulative spend. "Blocked" alone is a dead end.
  if (spend.task + quote.price > limits.perTask) {
    return refuse("PER_TASK_CEILING",
      { cumulative: spend.task, requested: quote.price, remaining: limits.perTask - spend.task },
      `Purchase blocked. You have spent $${spend.task} on this task; $${quote.price} would exceed the $${limits.perTask} ceiling. $${limits.perTask - spend.task} remaining.`);
  }

  // 4. per day
  if (spend.day + quote.price > limits.perDay) {
    return refuse("PER_DAY_CEILING",
      { cumulative: spend.day, requested: quote.price, remaining: limits.perDay - spend.day },
      `Purchase blocked. Daily ceiling of $${limits.perDay} would be exceeded.`);
  }

  // 5. circuit breaker
  if (spend.attempts >= limits.maxAttemptsPerTask) {
    return refuse("CIRCUIT_OPEN",
      { attempts: spend.attempts, cumulative: spend.task },
      `Purchase blocked. ${spend.attempts} recovery attempts already made on this task.`);
  }

  return { ok: true };
}

function refuse(reason: any, detail: Record<string, unknown>, message: string): GateResult {
  return { ok: false, reason, detail, message };
}
