import type { PurchaseOffer } from "@aisle/types";

export interface AdapterStep {
  action: "goto" | "click" | "fill" | "select";
  /** Accessible-name locators survive redesigns. CSS paths do not. */
  locator?: { role: string; name: string };
  fallbackCss?: string;
  value?: string;
  url?: string;
}

export interface VendorCapabilities {
  provider: string;
  purchaseCredits?: { toolName: string };
  subscribeToPlan?: { toolName: string };
  getBalance?: { toolName: string };
  recordedAdapter?: { version: number; steps: AdapterStep[] };
  knownOffers?: PurchaseOffer[];
}

const REGISTRY = new Map<string, VendorCapabilities>();

export function register(c: VendorCapabilities) { REGISTRY.set(c.provider, c); }
export function capabilities(provider: string) { return REGISTRY.get(provider); }

export type Lane = "fast" | "slow";
export function routeLane(provider: string): Lane {
  const c = REGISTRY.get(provider);
  return c?.purchaseCredits || c?.subscribeToPlan ? "fast" : "slow";
}

/** tier 3 -> tier 2 promotion. The fallback IS the recording mechanism. */
export function recordAdapter(provider: string, steps: AdapterStep[]) {
  const c = REGISTRY.get(provider) ?? { provider };
  const version = (c.recordedAdapter?.version ?? 0) + 1;
  REGISTRY.set(provider, { ...c, recordedAdapter: { version, steps } });
  return version;
}
