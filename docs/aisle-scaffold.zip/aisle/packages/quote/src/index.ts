import type { Blocker, Entitlement, PurchaseOffer, Quote } from "@aisle/types";

/**
 * "What is the minimum entitlement required to finish this task?"
 * NOT "what can I buy?"
 */
export function buildQuote(args: {
  provider: string;
  billingOrigin: string;
  blocker: Blocker;
  current: Entitlement | null;
  offers: PurchaseOffer[];
  perPurchaseCeiling: number;
  contextNote?: string;          // e.g. "3 hero images"
}): Quote | null {
  const { provider, billingOrigin, blocker, current, offers, perPurchaseCeiling } = args;

  const balance = current?.balance ?? 0;
  const required = blocker.required ?? 1;
  const shortfall = Math.max(0, required - balance);
  if (shortfall === 0) return null;                       // caller must ALREADY_COVERED

  const viable = offers
    .filter((o) => o.unitsGranted >= shortfall)
    .filter((o) => o.price <= perPurchaseCeiling)
    // prefer one_time even when a subscription is cheaper per unit:
    // the user is unblocking a task, not adopting a vendor.
    .sort((a, b) =>
      a.billing === b.billing ? a.price - b.price : a.billing === "one_time" ? -1 : 1);

  const best = viable[0];
  if (!best) return null;                                 // caller must refuse NO_VIABLE_OFFER

  return {
    provider,
    billingOrigin,                                        // from the LOCKED origin, never the page
    productId: best.productId,
    quantity: 1,
    unitsGranted: best.unitsGranted,
    price: best.price,
    currency: best.currency,
    billing: best.billing,
    autoRenew: false,
    reason: reason({ ...args, balance, required, shortfall, best }),
  };
}

function reason(a: any): string {
  const what = a.contextNote ? `${a.contextNote} ` : "";
  return `${what}needs ${fmt(a.required)} ${a.blocker.resource}. ` +
    `Balance ${fmt(a.balance)}. Smallest package that clears the ${fmt(a.shortfall)} shortfall ` +
    `is ${a.best.label} at $${a.best.price}.`;
}
const fmt = (n: number) => n.toLocaleString("en-US");
