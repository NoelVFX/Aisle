/**
 * THE CONTRACT BETWEEN LANES.
 * Agree these at H+0.5 and stop renegotiating them.
 */

// ---------------------------------------------------------------- blockers

export type BlockerType =
  | "INSUFFICIENT_CREDITS"
  | "QUOTA_EXCEEDED"
  | "PLAN_REQUIRED"
  | "SEAT_REQUIRED"
  | "PAYMENT_REQUIRED"
  | "UNKNOWN";

export interface Blocker {
  type: BlockerType;
  resource: string;              // "image_credits" | "usd_balance" | "seats"
  required?: number;             // parsed only if the vendor actually told us
  confidence: "high" | "low";    // low = body evicted, classified on status alone
  raw: unknown;
}

// ---------------------------------------------------------------- origin

/**
 * The single most important invariant in this codebase:
 * origins come from configuration (upstreams.json) or from an enrollment row.
 * NEVER from a tool result, a page, an error body, or a model.
 */
export interface LockedOrigin {
  provider: string;
  canonicalOrigin: string;       // where the API 402s from
  billingOrigin: string;         // where purchases happen
  source: "task_configuration" | "enrollment";
  lockedAt: string;
}

// ---------------------------------------------------------------- checkpoint

export interface TaskCheckpoint {
  taskId: string;
  agentId: string | null;
  toolCallId: string;
  surface: "cli" | "web";

  originalGoal: string | null;   // null on CLI. do not fabricate it.
  tool: string;
  arguments: unknown;
  argumentsHash: string;         // sha256 of canonical JSON

  origin: LockedOrigin;
  blocker: Blocker;
  createdAt: string;
}

// ---------------------------------------------------------------- entitlement

export interface Entitlement {
  userId: string;
  provider: string;
  accountId: string | null;      // distinguishes infra-openrouter from user-openrouter
  resource: string;
  balance: number | null;
  plan: string | null;
  seatsUsed: number | null;
  seatsTotal: number | null;
  status: "active" | "expired" | "cancelled";
  verifiedAt: string;
}

// ---------------------------------------------------------------- quote

export interface PurchaseOffer {
  productId: string;
  label: string;
  unitsGranted: number;
  price: number;
  currency: string;
  billing: "one_time" | "subscription";
  autoRenew: boolean;
}

export interface Quote {
  provider: string;
  billingOrigin: string;
  productId: string;
  quantity: number;
  unitsGranted: number;
  price: number;
  currency: string;
  billing: "one_time" | "subscription";
  autoRenew: boolean;
  reason: string;                // user-facing prose, generated in the engine not the UI
}

// ---------------------------------------------------------------- policy

export interface Limits {
  perPurchase: number;
  perTask: number;
  perDay: number;
  maxAttemptsPerTask: number;
  maxResolverCallsPerJob: number;
}

export interface SpendState {
  task: number;
  day: number;
  attempts: number;
}

export type RefusalReason =
  | "ORIGIN_VIOLATION"
  | "PER_PURCHASE_CEILING"
  | "PER_TASK_CEILING"
  | "PER_DAY_CEILING"
  | "CIRCUIT_OPEN"
  | "NO_VIABLE_OFFER"
  | "RESOLUTION_EXHAUSTED"
  | "INFRA_BLOCKED";

export type Refusal = {
  ok: false;
  reason: RefusalReason;
  detail: Record<string, unknown>;
  message: string;
};

export type GateResult = { ok: true } | Refusal;

// ---------------------------------------------------------------- mandate

export interface PurchaseMandate {
  mandateId: string;
  taskId: string;
  recoveryJobId: string;
  userId: string;

  provider: string;
  billingOrigin: string;
  productId: string;
  quantity: number;
  unitsGranted: number;

  maximumAmount: number;         // a CAP, not a price. tax moves the real number.
  currency: string;
  billingType: "one_time";
  autoRenew: false;

  expiresAt: string;
  nonce: string;
  signature: string;
}

export interface StagedCheckout {
  lineItem: string;
  amount: number;
  currency: string;
  billingPeriod: "one_time" | "subscription";
  autoRenew: boolean;
}

// ---------------------------------------------------------------- purchase

export type PurchaseStatus = "submitted" | "unknown" | "verified" | "failed";

export interface PurchaseResult {
  status: PurchaseStatus;
  lane: "fast" | "slow";
  transactionId?: string;
  balanceBefore?: number;
  balanceAfter?: number;
  steelSessionId?: string;
  traceExportId?: string;
  receiptFileIds?: string[];
  error?: unknown;
}

// ---------------------------------------------------------------- events

export type AisleEvent =
  | "TASK_CREATED" | "TOOL_CALL_STARTED" | "TOOL_CALL_FAILED"
  | "RECOVERY_CREATED" | "CHECKPOINT_FROZEN"
  | "ENTITLEMENT_CHECK_STARTED" | "ENTITLEMENT_CHECKED" | "ALREADY_COVERED"
  | "QUOTE_CREATED" | "POLICY_PASSED" | "POLICY_REFUSED"
  | "MANDATE_SIGNED" | "APPROVAL_REQUESTED" | "APPROVAL_GRANTED" | "APPROVAL_REJECTED"
  | "PURCHASE_STARTED" | "STEEL_SESSION_CREATED" | "PROFILE_RESTORED"
  | "RESOLVER_CALLED" | "CHECKOUT_STAGED" | "MANDATE_COMPARISON_PASSED"
  | "PURCHASE_SUBMITTED" | "TAKEOVER_REQUESTED" | "TAKEOVER_RESOLVED"
  | "PURCHASE_COMPLETED" | "PURCHASE_RESULT_UNKNOWN" | "RECEIPT_CAPTURED"
  | "ENTITLEMENT_VERIFIED" | "TRACE_EXPORTED"
  | "TOOL_CALL_RETRIED" | "TOOL_CALL_SUCCEEDED" | "TASK_RESUMED"
  | "ADAPTER_RECORDED" | "INFRA_CREDITS_EXHAUSTED"
  | "VIEWER_FROZEN" | "VIEWER_UNFROZEN" | "ENROLLMENT_SUGGESTED";

// ---------------------------------------------------------------- jobs

export type JobStatus =
  | "created" | "checking" | "quoting" | "awaiting_approval"
  | "purchasing" | "verifying" | "resolved" | "refused" | "failed";

export interface RecoveryJob {
  id: string;
  taskId: string;
  toolCallId: string | null;
  checkpoint: TaskCheckpoint;
  reqHash: string;               // sha256(provider + resource + amount) — idempotency
  status: JobStatus;
  lane: "fast" | "slow" | null;
  quote?: Quote;
  mandate?: PurchaseMandate;
  refusal?: Refusal;
  approveUrl: string;
}
