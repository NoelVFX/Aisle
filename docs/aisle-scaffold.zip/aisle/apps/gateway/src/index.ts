/**
 * MCP PROXY GATEWAY.
 *
 * The agent's config points HERE and nowhere else:
 *   claude mcp add --transport http aisle http://localhost:8788/mcp
 *
 * We re-export every upstream vendor's tools namespaced as {ns}__{tool},
 * so interception is structural rather than something the agent opts into.
 *
 * NOTE: the @modelcontextprotocol/sdk server API moves between versions.
 * Everything version-sensitive is confined to this file on purpose.
 */
import { readFileSync } from "node:fs";
import { randomUUID } from "node:crypto";
import { classifyToolError, isRateLimitNotWall } from "@aisle/detect";
import { handleBlocking, pendingResult, refusalResult } from "./recovery.js";
import type { LockedOrigin } from "@aisle/types";

interface Upstream {
  transport: "http";
  url: string;
  canonicalOrigin: string;
  billingOrigin: string;
  authEnv?: string;
}

const UPSTREAMS: Record<string, Upstream> =
  JSON.parse(readFileSync(new URL("../upstreams.json", import.meta.url), "utf8"));

export function lockedOrigin(ns: string): LockedOrigin {
  const u = UPSTREAMS[ns];
  if (!u) throw new Error(`UNKNOWN_UPSTREAM:${ns}`);
  return {
    provider: ns,
    canonicalOrigin: u.canonicalOrigin,
    billingOrigin: u.billingOrigin,
    source: "task_configuration",
    lockedAt: new Date().toISOString(),
  };
}

/** task_id without agent cooperation: derive it from the MCP session. */
export const taskIdFor = (mcpSessionId: string) => `task_${mcpSessionId}`;

/**
 * THE INTERCEPT. Everything hangs off this function.
 */
export async function callTool(req: {
  name: string;
  arguments: unknown;
  taskId: string;
  sendProgress: (m: string) => Promise<void>;
}) {
  const [ns, ...rest] = req.name.split("__");
  const toolName = rest.join("__");
  const up = UPSTREAMS[ns!];
  if (!up) throw new Error(`UNKNOWN_UPSTREAM:${ns}`);

  const toolCallId = randomUUID();
  const result = await callUpstream(up, toolName, req.arguments);

  if (!result.isError) return result;

  // 429 + Retry-After < 60 is a RATE LIMIT, not a billing wall.
  // Buying credits does not fix it. Keep this check ahead of classification.
  if (isRateLimitNotWall(result.status ?? 0, result.headers ?? {})) {
    await sleep((Number(result.headers?.["retry-after"]) || 5) * 1000);
    return callUpstream(up, toolName, req.arguments);
  }

  const blocker = classifyToolError(result, ns!);
  if (blocker.type === "UNKNOWN") return result;          // ordinary error, pass through untouched

  const outcome = await handleBlocking({
    taskId: req.taskId,
    toolCallId,
    tool: req.name,
    arguments: req.arguments,
    origin: lockedOrigin(ns!),
    blocker,
  }, req.sendProgress);

  if (outcome.resolved) {
    // Replay with the EXACT same arguments. Never regenerate the request.
    return callUpstream(up, toolName, req.arguments);
  }
  if ("pending" in outcome && outcome.pending) return pendingResult(outcome.job);
  return refusalResult(outcome.job);
}

async function callUpstream(up: Upstream, tool: string, args: unknown): Promise<any> {
  const headers: Record<string, string> = { "content-type": "application/json" };
  if (up.authEnv && process.env[up.authEnv]) headers.authorization = `Bearer ${process.env[up.authEnv]}`;

  const res = await fetch(`${up.url}/tools/${tool}`, {
    method: "POST", headers, body: JSON.stringify(args ?? {}),
  });
  const body = await res.text();
  if (res.ok) return { isError: false, content: [{ type: "text", text: body }] };
  return {
    isError: true,
    status: res.status,
    headers: Object.fromEntries(res.headers),
    error: safeJson(body),
  };
}

const safeJson = (s: string) => { try { return JSON.parse(s); } catch { return s; } };
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

if (process.argv[1]?.endsWith("index.ts")) {
  console.log("[gateway] upstreams:", Object.keys(UPSTREAMS).join(", "));
  console.log("[gateway] TODO: bind MCP StreamableHTTP transport on :8788 and route tools/call -> callTool()");
}
