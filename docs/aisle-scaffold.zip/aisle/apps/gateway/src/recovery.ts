import { createHash, randomUUID } from "node:crypto";
import type { Blocker, LockedOrigin, RecoveryJob, TaskCheckpoint } from "@aisle/types";

const API = process.env.AISLE_PUBLIC_URL ?? "http://localhost:8787";
const SAFE_BLOCK_MS = Number(process.env.SAFE_BLOCK_MS ?? 50_000);

export const canonicalHash = (v: unknown) =>
  createHash("sha256").update(JSON.stringify(v, Object.keys(v as object ?? {}).sort())).digest("hex");

export const requirementHash = (provider: string, resource: string, amount: number) =>
  createHash("sha256").update(`${provider}|${resource}|${amount}`).digest("hex");

export interface BlockContext {
  taskId: string;
  toolCallId: string;
  tool: string;
  arguments: unknown;
  origin: LockedOrigin;
  blocker: Blocker;
}

/**
 * THE BLOCKING CALL.
 * We hold the MCP tool call open rather than returning a resume token, so the
 * agent never learns a failure happened and never rebuilds its own context.
 */
export async function handleBlocking(ctx: BlockContext, sendProgress: (m: string) => Promise<void>) {
  const checkpoint: TaskCheckpoint = {
    taskId: ctx.taskId,
    agentId: null,
    toolCallId: ctx.toolCallId,
    surface: "cli",
    originalGoal: null,                    // CLI does not give us one. Do not fabricate.
    tool: ctx.tool,
    arguments: ctx.arguments,
    argumentsHash: canonicalHash(ctx.arguments),
    origin: ctx.origin,                    // ← from upstreams.json. never from the result.
    blocker: ctx.blocker,
    createdAt: new Date().toISOString(),
  };

  const job = await post<RecoveryJob>("/recovery", { checkpoint });
  await sendProgress(`Blocked on ${ctx.origin.provider}. Aisle is checking what you own — ${job.approveUrl}`);

  const deadline = Date.now() + SAFE_BLOCK_MS;
  while (Date.now() < deadline) {
    const state = await get<RecoveryJob>(`/recovery/${job.id}`);

    if (state.status === "resolved") return { resolved: true as const, job: state };
    if (state.status === "refused" || state.status === "failed") {
      return { resolved: false as const, job: state };
    }
    await sendProgress(statusLine(state));
    await sleep(1000);
  }

  // Handed back WITHOUT dying. The agent calls wait_for_recovery, which blocks again.
  return { resolved: false as const, pending: true as const, job };
}

export function pendingResult(job: RecoveryJob) {
  return {
    content: [{
      type: "text" as const,
      text: JSON.stringify({
        status: "AWAITING_APPROVAL",
        recovery_id: job.id,
        approve_url: job.approveUrl,
        // Without this line a helpful agent retries and opens a second job.
        next: "Call aisle__wait_for_recovery with this recovery_id. Do NOT re-run the original tool.",
      }, null, 2),
    }],
    isError: false,
  };
}

export function refusalResult(job: RecoveryJob) {
  return {
    content: [{
      type: "text" as const,
      text: job.refusal?.message ??
        "Aisle could not safely purchase additional resources within the configured spending limits.",
    }],
    isError: false,     // NOT an error — the agent should tell the user, not crash.
  };
}

const statusLine = (j: RecoveryJob) => ({
  created: "Recovery created",
  checking: "Checking existing entitlements",
  quoting: "Finding the smallest purchase that unblocks this",
  awaiting_approval: `Waiting for your approval — ${j.approveUrl}`,
  purchasing: `Purchasing via ${j.lane} lane`,
  verifying: "Verifying the entitlement landed",
}[j.status] ?? j.status);

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const get = async <T>(p: string): Promise<T> => (await fetch(API + p)).json() as Promise<T>;
const post = async <T>(p: string, b: unknown): Promise<T> =>
  (await fetch(API + p, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(b) })).json() as Promise<T>;
