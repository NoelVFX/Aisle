import Steel from "steel-sdk";
import { chromium, type Browser, type Page } from "playwright";

export const steel = new Steel({ steelAPIKey: process.env.STEEL_API_KEY! });

/**
 * steel.md 3 — THE MOST DANGEROUS THING IN THE PROJECT.
 * The docs name this param inconsistently (timeout / sessionTimeout / api_timeout).
 * An unrecognised key is SILENTLY IGNORED and you get the 5-minute default,
 * which kills the session mid-approval. timeout cannot be raised on a live session.
 */
export function assertTimeoutApplied(session: any, wantedMs: number) {
  const actual = session.timeout ?? session.sessionTimeout ?? session.apiTimeout;
  if (!actual || actual < wantedMs * 0.9) {
    throw new Error(
      `STEEL_TIMEOUT_PARAM_WRONG: asked for ${wantedMs}ms, session reports ${actual}. ` +
      `Fix the parameter name before doing anything else.`
    );
  }
}

export async function createPurchaseSession(profileId?: string) {
  const timeout = Number(process.env.STEEL_SESSION_TIMEOUT_MS ?? 900_000);
  const session = await steel.sessions.create({
    ...(profileId ? { profileId, persistProfile: true } : {}),
    useProxy: true,
    solveCaptcha: true,
    timeout,
    // inactivityTimeout: DELIBERATELY OMITTED.
    // We park this session while a human taps approve — there are no CDP
    // commands during that wait, which is exactly what it would kill.
    blockAds: true,
    dimensions: { width: 1280, height: 720 },
    // NO optimizeBandwidth here. Blocking media/CSS breaks 3DS iframes and
    // card-brand detection in ways that look like your code failing.
  } as any);
  assertTimeoutApplied(session, timeout);
  return session;
}

export async function connect(sessionId: string): Promise<{ browser: Browser; page: Page }> {
  const browser = await chromium.connectOverCDP(
    `wss://connect.steel.dev?apiKey=${process.env.STEEL_API_KEY}&sessionId=${sessionId}`
  );
  const context = browser.contexts()[0]!;
  // Steel hands you a page already open. Calling newContext() here would
  // silently discard the mounted profile you just paid to restore.
  const page = context.pages()[0]!;
  page.setDefaultTimeout(90_000);       // captcha solving takes tens of seconds
  return { browser, page };
}

/** Profiles persist on RELEASE, not during the run. Poll before any second run. */
export async function waitForProfileReady(profileId: string, timeoutMs = 60_000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const p = await (steel as any).profiles.retrieve(profileId).catch(() => null);
    if (p?.status === "READY") return;
    await new Promise((r) => setTimeout(r, 1500));
  }
  throw new Error("PROFILE_NOT_READY");
}

/** Keeps a parked session alive if you must set inactivityTimeout. */
export function heartbeat(cdp: any, ms = 20_000) {
  const h = setInterval(() => cdp.send("Runtime.evaluate", { expression: "1" }).catch(() => {}), ms);
  return () => clearInterval(h);
}
