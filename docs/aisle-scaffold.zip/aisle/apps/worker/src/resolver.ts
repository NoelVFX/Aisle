import OpenAI from "openai";
import type { Page } from "playwright";

/**
 * aisle-pipeline.md 16 — the model layer.
 * A model is NEVER in: the final submit, the policy gate, the origin decision,
 * the mandate comparison, or entitlement verification.
 */
export const resolver = new OpenAI({
  baseURL: "https://openrouter.ai/api/v1",
  apiKey: process.env.OPENROUTER_INFRA_KEY,      // NOT the demo vendor key. See 16.5.
  defaultHeaders: { "HTTP-Referer": "https://aisle.dev", "X-OpenRouter-Title": "Aisle" },
});

const PROFILES = {
  PICKER: { model: "anthropic/claude-sonnet-4.6", models: ["openai/gpt-5-mini", "google/gemini-3-flash-preview"] },
  VISION: { model: "anthropic/claude-sonnet-4.6", models: ["openai/gpt-5"] },
} as const;

const ACTIONABLE = new Set(["button", "link", "radio", "combobox", "checkbox", "menuitem"]);

export interface Candidate { index: number; role: string; name: string; near: string; backendNodeId: number }

/** Tier 3. Build a NUMBERED index of real nodes. Never ask for a CSS selector. */
export async function buildCandidates(page: Page): Promise<Candidate[]> {
  const cdp = await page.context().newCDPSession(page);
  const { nodes } = await cdp.send("Accessibility.getFullAXTree") as any;
  const out: Candidate[] = [];
  for (const n of nodes) {
    const role = n.role?.value;
    if (!ACTIONABLE.has(role)) continue;
    const name = n.name?.value ?? "";
    if (!name.trim()) continue;
    out.push({ index: out.length, role, name, near: "", backendNodeId: n.backendDOMNodeId });
  }
  return out;
}

export async function pick(requirement: string, candidates: Candidate[], jobId: string): Promise<Candidate> {
  if (process.env.REPLAY_RESOLVER === "1") return replay(jobId, candidates);
  if (bump(jobId) > Number(process.env.MAX_RESOLVER_CALLS_PER_JOB ?? 5)) {
    throw new Error("RESOLUTION_EXHAUSTED");
  }

  const prompt = `Requirement: ${requirement}
Candidates:
${candidates.map((c) => `[${c.index}] ${c.role} "${c.name}"${c.near ? ` near: ${c.near}` : ""}`).join("\n")}

Return ONLY: {"index": <number>, "why": "<12 words max>"}`;

  const res = await resolver.chat.completions.create({
    model: PROFILES.PICKER.model,
    messages: [{ role: "user", content: prompt }],
    response_format: { type: "json_object" },
    // the models array is not part of the OpenAI schema; it rides in extra_body
    ...({ extra_body: { models: PROFILES.PICKER.models } } as any),
  });

  const raw = JSON.parse(res.choices[0]?.message?.content ?? "{}");
  const idx = Number(raw.index);
  // VALIDATE. A model returning [47] for 12 candidates is a bug to catch here,
  // not in Chrome.
  if (!Number.isInteger(idx) || idx < 0 || idx >= candidates.length) {
    throw new Error(`RESOLVER_INDEX_OUT_OF_RANGE:${raw.index}`);
  }
  record(jobId, idx);
  return candidates[idx]!;
}

const CALLS = new Map<string, number>();
const bump = (id: string) => { const n = (CALLS.get(id) ?? 0) + 1; CALLS.set(id, n); return n; };
const RECORDED = new Map<string, number[]>();
const record = (id: string, i: number) => RECORDED.set(id, [...(RECORDED.get(id) ?? []), i]);
function replay(id: string, c: Candidate[]) {
  const next = RECORDED.get(id)?.shift();
  if (next === undefined) throw new Error("NO_RECORDED_CHOICE");
  return c[next]!;
}
