import { serve } from "@hono/node-server";
import { Hono } from "hono";
import type { PurchaseMandate, PurchaseResult, StagedCheckout } from "@aisle/types";
import { verifyMandate, assertMatchesMandate } from "@aisle/mandate";
import { createPurchaseSession, connect, waitForProfileReady } from "./steel.js";
import { buildCandidates, pick } from "./resolver.js";

/**
 * THE SLOW LANE. See steel.md 20 for the annotated walkthrough.
 */
export async function executeSlowLane(m: PurchaseMandate, profileId?: string): Promise<PurchaseResult> {
  verifyMandate(m);                                  // separate process — trust nothing

  const session = await createPurchaseSession(profileId);
  log("STEEL_SESSION_CREATED", session.sessionViewerUrl);
  const { browser, page } = await connect(session.id);

  let result: PurchaseResult = { status: "failed", lane: "slow", steelSessionId: session.id };
  let submitted = false;

  try {
    // 1. identity check BEFORE anything that matters
    await page.goto(`${m.billingOrigin}/account`);
    if (!(await isLoggedIn(page))) await reAuthenticate(page);

    // 2. read the offer. markdown/JSON-LD, not DOM scraping.
    await page.goto(`${m.billingOrigin}/pricing`);
    const balanceBefore = await readBalance(page);

    // 3. stage. do not submit yet.
    const staged = await stage(page, m);
    log("CHECKOUT_STAGED", staged);

    // 4. THE GATE. Aborts before any spend. A wrong click fails closed.
    assertMatchesMandate(staged, m);
    log("MANDATE_COMPARISON_PASSED", { staged: staged.amount, cap: m.maximumAmount });

    // 5. deterministic submit. NEVER the model path.
    submitted = true;
    await page.getByRole("button", { name: /complete purchase/i }).click({ timeout: 90_000 });

    // 6. verify by reading the balance, not the receipt
    const balanceAfter = await readBalance(page);
    if (balanceAfter < balanceBefore + m.unitsGranted) throw new Error("PURCHASE_VERIFICATION_FAILED");

    result = { status: "verified", lane: "slow", steelSessionId: session.id, balanceBefore, balanceAfter };
  } catch (e) {
    // After submit we genuinely don't know if the card was charged. NEVER retry.
    result = submitted
      ? { status: "unknown", lane: "slow", steelSessionId: session.id, error: String(e) }
      : { status: "failed",  lane: "slow", steelSessionId: session.id, error: String(e) };
  } finally {
    const trace = await exportTrace(session.id);
    if (trace) result.traceExportId = trace;
    await browser.close();
    await (await import("./steel.js")).steel.sessions.release(session.id);   // triggers profile write
  }

  if (result.status === "unknown") result = await resolveByObservation(m, result);
  if (result.status === "verified" && profileId) await waitForProfileReady(profileId);
  return result;
}

async function stage(page: any, m: PurchaseMandate): Promise<StagedCheckout> {
  // tier 1: the page may declare its own offers
  const offers = await page.$$eval('script[type="application/ld+json"]',
    (els: any[]) => els.map((e) => { try { return JSON.parse(e.textContent); } catch { return null; } }).filter(Boolean)
  ).catch(() => []);

  // tier 2/3: pick the product control
  const candidates = await buildCandidates(page);
  const target = await pick(`buy product ${m.productId} (${m.unitsGranted} units)`, candidates, m.recoveryJobId);
  await page.getByRole(target.role as any, { name: target.name }).click();

  await page.getByRole("link", { name: /checkout/i }).click().catch(() => {});
  return readStagedCheckout(page);
}

async function readStagedCheckout(page: any): Promise<StagedCheckout> {
  return {
    lineItem:      await text(page, "[data-checkout-line]"),
    amount:        Number((await text(page, "[data-checkout-amount]")).replace(/[^0-9.]/g, "")),
    currency:      (await text(page, "[data-checkout-currency]")) || "USD",
    billingPeriod: ((await text(page, "[data-checkout-period]")) || "one_time") as any,
    autoRenew:     (await text(page, "[data-checkout-autorenew]")) === "true",
  };
}

const text = async (p: any, sel: string) => (await p.locator(sel).first().textContent().catch(() => ""))?.trim() ?? "";
const isLoggedIn = (p: any) => p.locator("[data-account-email]").isVisible().catch(() => false);
async function reAuthenticate(_p: any) { /* Steel Credentials API — fills the login form */ }
const readBalance = async (p: any) => Number((await text(p, "[data-balance]")).replace(/[^0-9.]/g, "")) || 0;
async function exportTrace(id: string) {
  try { return (await (await import("./steel.js")).steel as any).traces?.export?.(id)?.id ?? null; }
  catch { return null; }
}
/** Purchase may or may not have happened. Decide from OBSERVED state, never by retrying. */
async function resolveByObservation(_m: PurchaseMandate, r: PurchaseResult) { return r; }

const log = (t: string, p?: unknown) => console.log(`[worker] ${t}`, p ?? "");

const app = new Hono();
app.post("/purchase", async (c) => c.json(await executeSlowLane(await c.req.json())));
serve({ fetch: app.fetch, port: 8789 });
console.log("[worker] http://localhost:8789");
