import type { BrowserContext, Page } from "playwright";
import { classify, isRateLimitNotWall } from "@aisle/detect";

/**
 * web-path.md 3 — THE WIRE TRIGGER.
 * Same classifier as the MCP path. Do not fork it.
 */
export async function attachDetectors(context: BrowserContext, ctx: {
  userId: string; taskId: string;
  lookupEnrollment: (origin: string) => Promise<Enrollment | null>;
  onBlocked: (b: any) => Promise<void>;
  onSuggestEnrollment: (origin: string) => void;
}) {
  const attach = async (page: Page) => {
    const cdp = await page.context().newCDPSession(page);
    await cdp.send("Network.enable");
    cdp.on("Network.responseReceived", (e: any) => onResponse(cdp, e, ctx).catch(console.error));
  };
  for (const p of context.pages()) await attach(p);
  // WITHOUT THIS you miss every 402 that happens in a new tab, which is most of them.
  context.on("page", attach);
}

export interface Enrollment { provider: string; canonicalOrigin: string; billingOrigin: string }

async function onResponse(cdp: any, e: any, ctx: any) {
  const { status, url, headers } = e.response;
  if (![402, 403, 429].includes(status)) return;

  // A rate limit is not a billing wall.
  if (isRateLimitNotWall(status, headers ?? {})) return;

  const origin = new URL(url).origin;
  const enrolled = await ctx.lookupEnrollment(origin);
  if (!enrolled) return ctx.onSuggestEnrollment(origin);   // toast. NEVER a quote.

  let body = ""; let bodyAvailable = true;
  try {
    ({ body } = await cdp.send("Network.getResponseBody", { requestId: e.requestId }));
  } catch {
    bodyAvailable = false;   // evicted. classify on status alone, mark low-confidence.
  }

  const blocker = classify(status, body, enrolled.provider, { bodyAvailable });
  if (blocker.type === "UNKNOWN") return;

  await ctx.onBlocked({
    blocker,
    origin: {
      provider: enrolled.provider,
      canonicalOrigin: enrolled.canonicalOrigin,
      // FROM THE ENROLLMENT ROW. Never from `url`, never from the body.
      billingOrigin: enrolled.billingOrigin,
      source: "enrollment",
      lockedAt: new Date().toISOString(),
    },
  });
}
