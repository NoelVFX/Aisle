import type { AisleEvent } from "@aisle/types";

/**
 * ONE event stream. Every UI is a projection of it:
 * CLI progress lines, approval card, Steel viewer overlay, demo timeline.
 * Build this BEFORE the UI.
 */
type Row = { id: number; taskId: string; type: AisleEvent; payload: any; at: string };

const log: Row[] = [];
const subs = new Map<string, Set<(r: Row) => void>>();
let seq = 0;

export async function emit(taskId: string, type: AisleEvent, payload: Record<string, unknown> = {}) {
  const row: Row = { id: ++seq, taskId, type, payload, at: new Date().toISOString() };
  log.push(row);
  console.log(`[${taskId.slice(-6)}] ${type}`, Object.keys(payload).length ? payload : "");
  subs.get(taskId)?.forEach((f) => f(row));
  // TODO: also INSERT INTO events
}

export const since = (taskId: string, afterId = 0) =>
  log.filter((r) => r.taskId === taskId && r.id > afterId);

export function subscribe(taskId: string, fn: (r: Row) => void) {
  if (!subs.has(taskId)) subs.set(taskId, new Set());
  subs.get(taskId)!.add(fn);
  return () => subs.get(taskId)!.delete(fn);
}
