import { createHash } from "node:crypto";
export const requirementHash = (provider: string, resource: string, amount: number) =>
  createHash("sha256").update(`${provider}|${resource}|${amount}`).digest("hex");
