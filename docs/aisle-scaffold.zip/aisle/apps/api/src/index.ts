import { serve } from "@hono/node-server";
import { Hono } from "hono";
import { createJob, getJob, approve, reject } from "./jobs.js";
import { since, subscribe } from "./events.js";
import { register } from "@aisle/registry";

register({
  provider: "mockvendor",
  purchaseCredits: { toolName: "purchase_credits" },
  getBalance: { toolName: "get_balance" },
  knownOffers: [
    { productId: "c1000", label: "1,000 credits", unitsGranted: 1000, price: 5,  currency: "USD", billing: "one_time", autoRenew: false },
    { productId: "c5000", label: "5,000 credits", unitsGranted: 5000, price: 20, currency: "USD", billing: "one_time", autoRenew: false },
    { productId: "c25000", label: "25,000 credits", unitsGranted: 25000, price: 80, currency: "USD", billing: "one_time", autoRenew: false },
  ],
});

const app = new Hono();

app.get("/health", (c) => c.json({ ok: true }));
app.post("/recovery", async (c) => c.json(await createJob((await c.req.json()).checkpoint)));
app.get("/recovery/:id", (c) => {
  const j = getJob(c.req.param("id"));
  return j ? c.json(j) : c.notFound();
});
app.post("/r/:id/approve", async (c) => c.json(await approve(c.req.param("id"))));
app.post("/r/:id/reject",  async (c) => c.json(await reject(c.req.param("id"))));

app.get("/r/:id/events", (c) => {
  const job = getJob(c.req.param("id"));
  if (!job) return c.notFound();
  return new Response(new ReadableStream({
    start(ctrl) {
      const send = (r: unknown) => ctrl.enqueue(new TextEncoder().encode(`data: ${JSON.stringify(r)}\n\n`));
      since(job.taskId).forEach(send);
      subscribe(job.taskId, send);
    },
  }), { headers: { "content-type": "text/event-stream", "cache-control": "no-cache" } });
});

serve({ fetch: app.fetch, port: 8787 });
console.log("[api] http://localhost:8787");
