import type { PurchaseMandate, PurchaseResult } from "@aisle/types";
import { verifyMandate } from "@aisle/mandate";
import { capabilities } from "@aisle/registry";
import { emit } from "./events.js";

const CONSUMED = new Set<string>();

/**
 * Single-use mandate consumption.
 * Real version is: UPDATE mandates SET status='consumed'
 *                  WHERE id=$1 AND status='approved' RETURNING *
 * Zero rows -> someone already used it -> abort. Do NOT purchase.
 */
function consume(mandateId: string): boolean {
  if (CONSUMED.has(mandateId)) return false;
  CONSUMED.add(mandateId);
  return true;
}

export async function executePurchase(m: PurchaseMandate, lane: "fast" | "slow"): Promise<PurchaseResult> {
  verifyMandate(m);
  if (!consume(m.mandateId)) return { status: "failed", lane, error: "MANDATE_ALREADY_USED" };

  if (process.env.FAKE_PURCHASE === "1") {
    await emit(m.taskId, "PURCHASE_SUBMITTED", { lane, stub: true });
    await new Promise((r) => setTimeout(r, 1200));
    await emit(m.taskId, "PURCHASE_COMPLETED", { amount: m.maximumAmount, stub: true });
    return { status: "verified", lane, balanceBefore: 0, balanceAfter: m.unitsGranted };
  }

  if (lane === "fast") return fastLane(m);
  // Slow lane lives in apps/worker (Steel). Hand off over HTTP.
  const res = await fetch(`${process.env.WORKER_URL ?? "http://localhost:8789"}/purchase`, {
    method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(m),
  });
  return res.json() as Promise<PurchaseResult>;
}

async function fastLane(m: PurchaseMandate): Promise<PurchaseResult> {
  const caps = capabilities(m.provider);
  const tool = caps?.purchaseCredits?.toolName;
  if (!tool) return { status: "failed", lane: "fast", error: "NO_PURCHASE_TOOL" };

  const r = await fetch(`${process.env.MOCK_VENDOR_URL}/tools/${tool}`, {
    method: "POST", headers: { "content-type": "application/json" },
    body: JSON.stringify({
      product_id: m.productId, quantity: m.quantity,
      idempotency_key: `purchase:${m.taskId}:${m.mandateId}`,
    }),
  });
  const body = await r.json() as any;
  await emit(m.taskId, "PURCHASE_COMPLETED", { lane: "fast", txn: body.transaction_id });

  // The fast lane does NOT skip verification. {success:true} is a claim, not an entitlement.
  const bal = await fetch(`${process.env.MOCK_VENDOR_URL}/api/balance`).then((x) => x.json()) as any;
  return {
    status: bal.balance >= m.unitsGranted ? "verified" : "failed",
    lane: "fast", transactionId: body.transaction_id, balanceAfter: bal.balance,
  };
}
