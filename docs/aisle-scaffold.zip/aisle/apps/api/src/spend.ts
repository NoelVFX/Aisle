import type { SpendState } from "@aisle/types";

const AMT = new Map<string, number>();
const ATT = new Map<string, number>();
const day = () => new Date().toISOString().slice(0, 10);

export async function getSpend(taskId: string, userId: string): Promise<SpendState> {
  return {
    task: AMT.get(`task:${taskId}`) ?? 0,
    day: AMT.get(`day:${userId}:${day()}`) ?? 0,
    attempts: ATT.get(`task:${taskId}`) ?? 0,
  };
}
export async function addSpend(taskId: string, userId: string, amount: number) {
  AMT.set(`task:${taskId}`, (AMT.get(`task:${taskId}`) ?? 0) + amount);
  const dk = `day:${userId}:${day()}`;
  AMT.set(dk, (AMT.get(dk) ?? 0) + amount);
}
export async function bumpAttempts(taskId: string) {
  ATT.set(`task:${taskId}`, (ATT.get(`task:${taskId}`) ?? 0) + 1);
}
