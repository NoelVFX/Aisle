import { randomUUID } from "node:crypto";
import type { PurchaseMandate, Quote, RecoveryJob, Refusal, TaskCheckpoint } from "@aisle/types";
import { gate, LIMITS } from "@aisle/policy";
import { buildQuote } from "@aisle/quote";
import { signMandate } from "@aisle/mandate";
import { routeLane, capabilities } from "@aisle/registry";
import { emit } from "./events.js";
import { requirementHash } from "./hash.js";
import { readEntitlement, refreshEntitlement, creditEntitlement } from "./ledger.js";
import { getSpend, addSpend, bumpAttempts } from "./spend.js";
import { executePurchase } from "./purchase.js";

const JOBS = new Map<string, RecoveryJob>();
const BY_HASH = new Map<string, string>();      // `${taskId}:${reqHash}` -> jobId
const PUBLIC = process.env.AISLE_PUBLIC_URL ?? "http://localhost:8787";

export const getJob = (id: string) => JOBS.get(id);

export async function createJob(checkpoint: TaskCheckpoint): Promise<RecoveryJob> {
  const { provider } = checkpoint.origin;
  const amount = checkpoint.blocker.required ?? 1;
  const reqHash = requirementHash(provider, checkpoint.blocker.resource, amount);
  const key = `${checkpoint.taskId}:${reqHash}`;

  // IDEMPOTENCY. Agent retried, or both surfaces saw the same shortfall.
  const existing = BY_HASH.get(key);
  if (existing) return JOBS.get(existing)!;

  const job: RecoveryJob = {
    id: randomUUID(), taskId: checkpoint.taskId, toolCallId: checkpoint.toolCallId,
    checkpoint, reqHash, status: "created", lane: null,
    approveUrl: `${PUBLIC}/r/${""}`,
  };
  job.approveUrl = `${PUBLIC}/r/${job.id}`;
  JOBS.set(job.id, job); BY_HASH.set(key, job.id);

  await emit(job.taskId, "RECOVERY_CREATED", { provider, resource: checkpoint.blocker.resource });
  await emit(job.taskId, "CHECKPOINT_FROZEN", { origin: checkpoint.origin.billingOrigin });

  void advance(job);      // fire and forget; the gateway polls
  return job;
}

async function advance(job: RecoveryJob) {
  try {
    const cp = job.checkpoint;
    const { provider } = cp.origin;

    // ---- entitlement check. This is where we sometimes DON'T buy. -------------
    job.status = "checking";
    await emit(job.taskId, "ENTITLEMENT_CHECK_STARTED", { provider });
    const current = await refreshEntitlement("demo-user", provider, cp.blocker.resource);
    await emit(job.taskId, "ENTITLEMENT_CHECKED", { provider, balance: current?.balance ?? 0 });

    const required = cp.blocker.required ?? 1;
    if ((current?.balance ?? 0) >= required) {
      await emit(job.taskId, "ALREADY_COVERED", { balance: current?.balance, required });
      job.status = "resolved";
      return;
    }

    // ---- quote ---------------------------------------------------------------
    job.status = "quoting";
    const offers = capabilities(provider)?.knownOffers ?? [];
    const quote = buildQuote({
      provider, billingOrigin: cp.origin.billingOrigin, blocker: cp.blocker,
      current, offers, perPurchaseCeiling: LIMITS.perPurchase,
    });
    if (!quote) return refuse(job, {
      ok: false, reason: "NO_VIABLE_OFFER", detail: { required },
      message: "No package under the per-purchase ceiling clears the shortfall.",
    });
    job.quote = quote;
    await emit(job.taskId, "QUOTE_CREATED", { price: quote.price, units: quote.unitsGranted, reason: quote.reason });

    // ---- policy gate ---------------------------------------------------------
    const spend = await getSpend(job.taskId, "demo-user");
    const g = gate(quote, cp, spend);
    if (!g.ok) return refuse(job, g);
    await emit(job.taskId, "POLICY_PASSED", {
      taskRemaining: LIMITS.perTask - spend.task, dayRemaining: LIMITS.perDay - spend.day,
    });

    // ---- mandate + approval --------------------------------------------------
    job.mandate = signMandate(quote, { taskId: job.taskId, recoveryJobId: job.id, userId: "demo-user" });
    await emit(job.taskId, "MANDATE_SIGNED", { mandateId: job.mandate.mandateId, cap: job.mandate.maximumAmount });
    job.status = "awaiting_approval";
    await emit(job.taskId, "APPROVAL_REQUESTED", { url: job.approveUrl });
    // -> resumes in approve()
  } catch (e) {
    job.status = "failed";
    console.error("[jobs] advance failed", e);
  }
}

const APPROVED = new Set<string>();   // idempotency on approval:{mandateId}

export async function approve(jobId: string) {
  const job = JOBS.get(jobId);
  if (!job?.mandate) throw new Error("NO_MANDATE");
  if (APPROVED.has(job.mandate.mandateId)) return job;   // double-tap on flaky wifi
  APPROVED.add(job.mandate.mandateId);

  await emit(job.taskId, "APPROVAL_GRANTED", {});
  job.lane = routeLane(job.checkpoint.origin.provider);
  job.status = "purchasing";
  await bumpAttempts(job.taskId);
  await emit(job.taskId, "PURCHASE_STARTED", { lane: job.lane });

  const result = await executePurchase(job.mandate, job.lane);

  if (result.status !== "verified") {
    job.status = "failed";
    await emit(job.taskId, "PURCHASE_RESULT_UNKNOWN", { status: result.status });
    return job;
  }

  await addSpend(job.taskId, "demo-user", job.quote!.price);
  await creditEntitlement("demo-user", job.checkpoint.origin.provider,
    job.checkpoint.blocker.resource, job.mandate.unitsGranted);
  await emit(job.taskId, "ENTITLEMENT_VERIFIED",
    { before: result.balanceBefore, after: result.balanceAfter });
  job.status = "resolved";
  await emit(job.taskId, "TASK_RESUMED", {});
  return job;
}

export async function reject(jobId: string) {
  const job = JOBS.get(jobId);
  if (!job) throw new Error("NO_JOB");
  job.status = "refused";
  job.refusal = { ok: false, reason: "CIRCUIT_OPEN", detail: {}, message: "Purchase rejected by the user." };
  await emit(job.taskId, "APPROVAL_REJECTED", {});
  return job;
}

async function refuse(job: RecoveryJob, r: Refusal) {
  job.status = "refused"; job.refusal = r;
  // A refusal ALWAYS reports cumulative spend. "Blocked" alone is a dead end.
  await emit(job.taskId, "POLICY_REFUSED", { reason: r.reason, ...r.detail });
}
