import type { Entitlement } from "@aisle/types";

/**
 * THE LEDGER IS A CACHE, NEVER TRUTH.
 * Read it to decide whether to act; re-verify against the vendor before quoting,
 * and again after purchase.
 */
const STALE_MS = 60_000;
const MEM = new Map<string, Entitlement>();
const key = (u: string, p: string, a: string, r: string) => `${u}|${p}|${a}|${r}`;

export async function readEntitlement(userId: string, provider: string, resource: string, accountId = "default") {
  return MEM.get(key(userId, provider, accountId, resource)) ?? null;
}

export async function refreshEntitlement(userId: string, provider: string, resource: string, accountId = "default") {
  const existing = await readEntitlement(userId, provider, resource, accountId);
  const fresh = existing && Date.now() - new Date(existing.verifiedAt).getTime() < STALE_MS;
  if (fresh) return existing;

  const balance = await readVendorBalance(provider, resource);
  const row: Entitlement = {
    userId, provider, accountId, resource, balance,
    plan: null, seatsUsed: null, seatsTotal: null,
    status: "active", verifiedAt: new Date().toISOString(),
  };
  MEM.set(key(userId, provider, accountId, resource), row);
  return row;
}

export async function creditEntitlement(userId: string, provider: string, resource: string, units: number, accountId = "default") {
  const row = await refreshEntitlement(userId, provider, resource, accountId);
  row.balance = (row.balance ?? 0) + units;
  row.verifiedAt = new Date().toISOString();
  MEM.set(key(userId, provider, accountId, resource), row);
  return row;
}

async function readVendorBalance(provider: string, resource: string): Promise<number> {
  if (provider === "mockvendor") {
    const r = await fetch(`${process.env.MOCK_VENDOR_URL ?? "http://localhost:8080"}/api/balance`);
    return (await r.json() as any).balance ?? 0;
  }
  return 0;
}
